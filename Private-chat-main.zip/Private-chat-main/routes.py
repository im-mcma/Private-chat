from flask import Flask, render_template, request, redirect, url_for, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import uuid
from models import db, User, ChatRoom, Message

app = Flask(__name__)
app.config.from_pyfile('config.py')
db.init_app(app)

def generate_uuid():
    return str(uuid.uuid4())

@app.before_first_request
def create_tables():
    db.create_all()

def get_user_from_request():
    user_id = request.cookies.get('user_id')
    username = request.cookies.get('username')
    if user_id and username:
        user = User.query.filter_by(id=user_id, username=username).first()
        if user:
            return user
    # اگر کاربر پیدا نشد، ساختش کن
    username = f"User{str(uuid.uuid4())[:8]}"
    user = User(id=generate_uuid(), username=username)
    db.session.add(user)
    db.session.commit()
    return user

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create_room', methods=['POST'])
def create_room():
    name = request.form.get('room_name') or f"Room-{str(uuid.uuid4())[:8]}"
    expire_seconds = int(request.form.get('expire_seconds') or 30)
    room = ChatRoom(id=generate_uuid(), name=name, expire_seconds=expire_seconds)
    db.session.add(room)
    db.session.commit()
    return redirect(url_for('chat_room', room_id=room.id))

@app.route('/chat/<room_id>')
def chat_room(room_id):
    room = ChatRoom.query.filter_by(id=room_id).first()
    if not room:
        return "Room not found", 404
    user = get_user_from_request()
    messages = Message.query.filter_by(chatroom_id=room_id).order_by(Message.timestamp.asc()).all()
    resp = make_response(render_template('chat.html', room=room, user=user, messages=messages))
    # کوکی‌ها را ست کن
    resp.set_cookie('user_id', user.id, max_age=60*60*24*30)
    resp.set_cookie('username', user.username, max_age=60*60*24*30)
    return resp

@app.route('/send_message/<room_id>', methods=['POST'])
def send_message(room_id):
    room = ChatRoom.query.filter_by(id=room_id).first()
    if not room:
        return jsonify({"error": "Room not found"}), 404

    user = get_user_from_request()
    content = request.form.get('content')
    if not content:
        return jsonify({"error": "No message content"}), 400

    msg = Message(
        id=generate_uuid(),
        chatroom_id=room.id,
        user_id=user.id,
        content=content,
        timestamp=datetime.utcnow(),
        is_file=False
    )
    db.session.add(msg)
    db.session.commit()
    return jsonify({
        "message": content,
        "user": user.username,
        "timestamp": msg.timestamp.isoformat()
    })

if __name__ == '__main__':
    app.run(debug=True)
