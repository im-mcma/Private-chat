import uuid
import hashlib
from datetime import datetime, timedelta

def generate_unique_chat_id():
    """تولید شناسه یکتا برای هر چت"""
    return uuid.uuid4().hex

def hash_username(username):
    """هش کردن نام کاربری برای حفظ حریم خصوصی"""
    return hashlib.sha256(username.encode()).hexdigest()

def message_expired(created_at, lifetime_seconds):
    """بررسی اینکه آیا پیام منقضی شده یا نه"""
    expiration_time = created_at + timedelta(seconds=lifetime_seconds)
    return datetime.utcnow() > expiration_time
