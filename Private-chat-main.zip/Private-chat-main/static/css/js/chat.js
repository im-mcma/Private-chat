const socket = io();

const messageForm = document.getElementById('messageForm');
const messageInput = document.getElementById('messageInput');
const messagesContainer = document.querySelector('.chat-messages');
const leaveBtn = document.getElementById('leaveBtn');
const fileInput = document.getElementById('fileInput');

const chatId = window.location.pathname.split('/').pop();

function addMessage(data, self = false) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message');
  messageDiv.classList.add(self ? 'self' : 'other');

  if (data.type === 'file') {
    const link = document.createElement('a');
    link.href = data.content;
    link.target = '_blank';
    link.textContent = data.filename || 'File';
    link.style.color = self ? 'white' : '#ccc';
    messageDiv.appendChild(link);
  } else {
    messageDiv.textContent = data.content;
  }

  const timeSpan = document.createElement('span');
  timeSpan.classList.add('time');
  const time = new Date(data.timestamp);
  timeSpan.textContent = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  messageDiv.appendChild(timeSpan);

  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

socket.on('connect', () => {
  socket.emit('join', { chat_id: chatId });
});

socket.on('message', (data) => {
  addMessage(data, false);
});

messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  if (messageInput.value.trim() === '') return;

  const messageData = {
    content: messageInput.value.trim(),
    type: 'text',
  };
  addMessage({ ...messageData, timestamp: new Date() }, true);
  socket.emit('send_message', { chat_id: chatId, ...messageData });
  messageInput.value = '';
});

leaveBtn.addEventListener('click', () => {
  window.location.href = '/';
});

// آپلود فایل
fileInput.addEventListener('change', () => {
  const file = fileInput.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    const base64Data = reader.result;
    const messageData = {
      content: base64Data,
      type: 'file',
      filename: file.name,
    };
    addMessage({ ...messageData, timestamp: new Date() }, true);
    socket.emit('send_message', { chat_id: chatId, ...messageData });
  };
  reader.readAsDataURL(file);
  fileInput.value = '';
});
