class Config:
    SQLALCHEMY_DATABASE_URI = "postgresql://dbchatroom_user:9qRUJQRw0n0ydjUF2VskwFXV1YfGXj6o@dpg-d0uakvumcj7s739gatrg-a.oregon-postgres.render.com/dbchatroom"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = "some-super-secret-key"
    MESSAGE_LIFETIME_SECONDS = 1800
